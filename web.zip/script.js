let result = prompt("Атыңыз кім?: ");
alert("Сәлеметсізбе, " + (result));
alert(`Сәлеметсізбе, ${result}!`);

